Oracle.ManagedDataAccess.Core NuGet Package 2.19.50 README
==========================================================

Release Notes: Oracle Data Provider for .NET Core

October 2019


New Features
============
1. .NET Core 3.0 certification 


Bug Fixes since Oracle.ManagedDataAccess.Core NuGet Package 2.19.31
===================================================================
Bug 30266960 : NEW CONNECTION CREATION DELAY WHEN CONNECTIONS HAVE BEEN SEVERED
