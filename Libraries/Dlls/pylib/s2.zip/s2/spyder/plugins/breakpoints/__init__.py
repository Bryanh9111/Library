# -*- coding: utf-8 -*-
# -----------------------------------------------------------------------------
# Copyright (c) 2009- Spyder Project Contributors
#
# Distributed under the terms of the MIT License
# (see spyder/__init__.py for details)
# -----------------------------------------------------------------------------


# =============================================================================
# The following statement is required to register this 3rd party plugin:
# =============================================================================

from .plugin import Breakpoints as PLUGIN_CLASS
