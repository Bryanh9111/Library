# This empty file makes the sphinxcontrib namespace package work.
# It is the only file included in the 'sphinxcontrib' conda package.
# Conda packages which use the sphinxcontrib namespace do not include
# this file, but depend on the 'sphinxcontrib' conda package instead.
