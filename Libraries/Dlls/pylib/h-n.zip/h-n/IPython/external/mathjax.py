#!/usr/bin/python
"""
`IPython.external.mathjax` is deprecated with IPython 4.0+

mathjax is now install by default with the notebook package

"""

import sys 

if __name__ == '__main__' :
    sys.exit("IPython.external.mathjax is deprecated, Mathjax is now installed by default with the notebook package")

