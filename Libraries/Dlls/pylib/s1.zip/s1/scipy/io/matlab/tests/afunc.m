function [a, b] = afunc(c, d)
% A function
a = c + 1;
b = d + 10;
